<?php session_start(); ?>

<?php
if(!isset($_SESSION['valid'])) {
	header('Location: login.php');
}
?>

<html>
<head>
	<title>Add Experiance</title>
	<link rel="stylesheet" href="experience.css">
</head>

<body>
<?php
//including the database connection file
include_once("connection.php");

if(isset($_POST['Submit'])) {	
	$firstname = $_POST['first_name'];
	$lastname = $_POST['last_name'];
	$designation = $_POST['designation'];
	$phone = $_POST['phone'];
	$email = $_POST['email'];
    $address = $_POST['address'];
	$userId = $_SESSION['id'];
		
	// checking empty fields
	if(empty($first_name) || empty($last_date) || empty($designation) || empty($phone) || empty($email)|| empty($address)) {
				
		if(empty($first_name)) {
			echo "<font color='red'>Company Name field is empty.</font><br/>";
		}
		
		if(empty($last_date)) {
			echo "<font color='red'>Date field is empty.</font><br/>";
		}
		
		if(empty($designation)) {
			echo "<font color='red'>Position field is empty.</font><br/>";
		}

		if(empty($phone)) {
			echo "<font color='red'>Address field is empty.</font><br/>";
		}

		if(empty($email)) {
			echo "<font color='red'>Description field is empty.</font><br/>";
		}
        if(empty($address)) {
			echo "<font color='red'>Description field is empty.</font><br/>";

        }
		//link to the previous page
		echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
	} else { 
		// if all the fields are filled (not empty) 
			
		//insert data to database	
		$result = mysqli_query($mysqli, "INSERT INTO information(first_name, last_name, designation, phone, email,addresss, user_id) VALUES('$firstname','$lastname','$designation', '$phone', '$email','$address','$userId')");
		
		//display success message
		echo "<br><font color='green'>Data added successfully.<br>";
		echo "<br/><a href='viewExperience.php'>View Experience</a>";
	}
}
?>





	<a href="index.php">Home</a> | <a href="education.php">Add Education</a> | <a href="logout.php">Logout</a>
	<br/><br/>

	<form action="addExperience.php" method="post" name="form1">
		<table width="25%" border="0">
			<br><h2>Add Experiance</h2><br>
			
			<tr>
				<td>Company Name</td>
				<td><input type="text" name="first_name"></td>
			</tr>
			<tr>
				<td>Position</td>
				<td><input type="text" name="last_name"></td>
			</tr>
			<tr>
				<td>End Date</td>
				<td><input type="date" name="designation"></td>
			</tr>
			<tr>
				<td>Address</td>
				<td><textarea type="text" name="phone"></textarea></td>
			</tr>
			<tr>
				<td>Description</td>
				<td><textarea type="text" name="email"></textarea></td>
			</tr>
            <tr>
				<td>Description</td>
				<td><textarea type="text" name="address"></textarea></td>
			</tr>
			<tr> 
				<td></td>
				<td><input type="submit" name="Submit" value="Add"> <br> <br><br> <a href="education.php">Add Education</a></td>
			</tr>
		</table>
	</form>


</body>
</html>