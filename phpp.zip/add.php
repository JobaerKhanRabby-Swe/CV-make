<?php session_start(); ?>

//<?php
//if(!isset($_SESSION['valid'])) {
//	header('Location: login.php');
//}
//?>

<html>
<head>
	<title>Add Information</title>
</head>


<?php
//including the database connection file
include_once("connection.php");

if(isset($_POST['Submit'])) {	
	$fullName = $_POST['fullName'];
	$lastName = $_POST['lastName'];
	$designation = $_POST['designation'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $website = $_POST['website'];
    $address = $_POST['address'];
	$userId = $_SESSION['id'];
		
	// checking empty fields
	if(empty($fullName) || empty($lastName) || empty($designation) || empty($phone)  || empty($email) || empty($website)  || empty($address)) {
				
		if(empty($fullName)) {
			echo "<font color='red'>Full Name field is empty.</font><br/>";
		}
		
		if(empty($lastName)) {
			echo "<font color='red'>Last Name field is empty.</font><br/>";
		}
		
		if(empty($designation)) {
			echo "<font color='red'>Designation field is empty.</font><br/>";
		}
        
        if(empty($phone)) {
			echo "<font color='red'>Phone field is empty.</font><br/>";
        }
        if(empty($email)) {
			echo "<font color='red'>Email field is empty.</font><br/>";
        }
		 if(empty($website)) {
			echo "<font color='red'>Website field is empty.</font><br/>";
         }
         if(empty($addres)) {
			echo "<font color='red'>Address field is empty.</font><br/>";
         }
		//link to the previous page
		echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
	} else { 
		// if all the fields are filled (not empty) 
			
		//insert data to database	
		$result = mysqli_query($mysqli, "INSERT INTO information(fullname, lastname, designation, phone, email, website, address, user_Id) VALUES('$fullname','$lastname','$designation', '$phone','$email','$website','$address','$userId')");
		
		//display success message
	echo "<br><font color='green'>Data added successfully.<br>";
		echo "<br/><a href='personalInformationView.php'>View Personal Information</a>";
	}
}
?>
   <body>h4
    <a href="index.php">Home</a> | <a href="add.php">View Products</a> | <a href="logout.php">Logout</a>
	<br/><br/>

	<form action="add.php" method="post" name="form1">
		<table width="25%" border="0">
			<tr> 
				<td>Name</td>
				<td><input type="text" name="fullName"></td>
			</tr>
			<tr> 
				<td>Quantity</td>
				<td><input type="text" name="lastName"></td>
			</tr>
			<tr> 
				<td>Price</td>
				<td><input type="text" name="designation"></td>
			</tr>
            <tr> 
				<td>Price</td>
				<td><input type="text" name="phone"></td>
			</tr>
            <tr> 
				<td>Price</td>
				<td><input type="text" name="email"></td>
			</tr>
            <tr> 
				<td>Price</td>
				<td><input type="text" name="website"></td>
			</tr>
            <tr> 
				<td>Price</td>
				<td><input type="text" name="address"></td>
			</tr>
			<tr> 
				<td></td>
				<td><input type="submit" name="Submit" value="Add"></td>
			</tr>
		</table>
	</form>
</body>
</html>
